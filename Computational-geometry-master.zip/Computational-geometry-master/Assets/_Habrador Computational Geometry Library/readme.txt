This open-source Computational Geometry Library is from https://github.com/Habrador/Computational-geometry

By Erik Nordeus (www.habrador.com)
