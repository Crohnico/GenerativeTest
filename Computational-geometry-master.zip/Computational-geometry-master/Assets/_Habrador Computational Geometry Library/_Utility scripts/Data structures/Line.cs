using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Habrador_Computational_Geometry
{
    //THIS IS A REMINDER TO NOT IMPLEMENT LINE DATA STRUCTURE
    //USE EDGE INSTEAD WHICH IS THE SAME
}
